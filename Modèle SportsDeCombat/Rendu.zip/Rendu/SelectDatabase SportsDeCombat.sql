/*
 * Authors : Christopher Miguel
 * Project : Sports de combat
 * Date : 26.01.2020
*/

-- select Styles
select * from Styles;

-- select Gears
select * from Gears;

-- select Statistics
select * from Statistics;

-- select Clubs
select * from Clubs;

-- select Fighters
select * from Fighters;

-- select Status
select * from Status;

-- select Sponsors
select * from Sponsors;

-- select Contests
select * from Contests;

-- select Categories
select * from Categories;

-- select Titles
select * from Titles;

-- select viewFairphone
select * from viewStportDeCombat;